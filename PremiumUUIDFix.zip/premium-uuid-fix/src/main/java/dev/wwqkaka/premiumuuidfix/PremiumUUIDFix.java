package dev.wwqkaka.premiumuuidfix;

import com.google.inject.Inject;
import com.velocitypowered.api.event.PostOrder;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.connection.PreLoginEvent;
import com.velocitypowered.api.event.proxy.ProxyInitializeEvent;
import com.velocitypowered.api.plugin.Dependency;
import com.velocitypowered.api.plugin.Plugin;
import com.velocitypowered.api.plugin.PluginContainer;
import com.velocitypowered.api.proxy.ProxyServer;
import org.slf4j.Logger;

import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Forces Mojang authentication (online mode) for every nickname that LimboAuth
 * has stored as a premium account (PREMIUMUUID set, HASH empty).
 *
 * Result: those players always get their REAL Mojang UUID. If Mojang cannot
 * verify them they are kicked instead of silently entering with an offline UUID
 * (which is what splits their data into two UUIDs).
 *
 * LimboAuth is accessed by reflection, so no LimboAuth jar is needed to build.
 */
@Plugin(
    id = "premiumuuidfix",
    name = "PremiumUUIDFix",
    version = "1.0.0",
    authors = {"Wwqkaka"},
    dependencies = {@Dependency(id = "limboauth")}
)
public final class PremiumUUIDFix {

  private final ProxyServer server;
  private final Logger logger;

  private volatile Object dao;
  private volatile Method queryForId;
  private volatile Method getPremiumUuid;
  private volatile Method getHash;

  @Inject
  public PremiumUUIDFix(ProxyServer server, Logger logger) {
    this.server = server;
    this.logger = logger;
  }

  @Subscribe
  public void onInit(ProxyInitializeEvent event) {
    try {
      Object limbo = server.getPluginManager().getPlugin("limboauth")
          .flatMap(PluginContainer::getInstance)
          .orElseThrow(() -> new IllegalStateException("LimboAuth instance not found"));

      Object d = limbo.getClass().getMethod("getPlayerDao").invoke(limbo);
      Method q = findPublicMethod(d.getClass(), "queryForId", 1);
      if (q == null) {
        throw new IllegalStateException("queryForId not found on LimboAuth DAO");
      }

      // Probe once with a name that does not exist to get the row class safely.
      Class<?> rowClass = Class.forName(
          "net.elytrium.limboauth.model.RegisteredPlayer", true, limbo.getClass().getClassLoader());
      this.getPremiumUuid = rowClass.getMethod("getPremiumUuid");
      this.getHash = rowClass.getMethod("getHash");
      this.queryForId = q;
      this.dao = d;
      logger.info("PremiumUUIDFix active: premium nicknames from LimboAuth are forced to online mode.");
    } catch (Throwable t) {
      logger.error("PremiumUUIDFix could not hook into LimboAuth, it will do NOTHING. "
          + "Check your LimboAuth version.", t);
    }
  }

  @Subscribe(order = PostOrder.LAST)
  public void onPreLogin(PreLoginEvent event) {
    Object d = this.dao;
    if (d == null || !event.getResult().isAllowed()) {
      return;
    }
    String name = event.getUsername();
    try {
      Object row = queryForId.invoke(d, name.toLowerCase(Locale.ROOT));
      if (row == null) {
        return;
      }
      String premiumUuid = (String) getPremiumUuid.invoke(row);
      String hash = (String) getHash.invoke(row);
      boolean premium = premiumUuid != null && !premiumUuid.isBlank()
          && (hash == null || hash.isEmpty());
      if (premium) {
        event.setResult(PreLoginEvent.PreLoginComponentResult.forceOnlineMode());
      }
    } catch (Throwable t) {
      // Fail open: never block logins because of a bug in this plugin.
      logger.warn("PremiumUUIDFix lookup failed for {}: {}", name, t.toString());
    }
  }

  /** Finds a public method on a public class/interface in the hierarchy (DAO impls are often non-public). */
  private static Method findPublicMethod(Class<?> type, String name, int params) {
    Set<Class<?>> seen = new HashSet<>();
    return search(type, name, params, seen);
  }

  private static Method search(Class<?> c, String name, int params, Set<Class<?>> seen) {
    if (c == null || !seen.add(c)) {
      return null;
    }
    if (java.lang.reflect.Modifier.isPublic(c.getModifiers())) {
      for (Method m : c.getMethods()) {
        if (m.getName().equals(name) && m.getParameterCount() == params
            && java.lang.reflect.Modifier.isPublic(m.getDeclaringClass().getModifiers())) {
          return m;
        }
      }
    }
    for (Class<?> i : c.getInterfaces()) {
      Method m = search(i, name, params, seen);
      if (m != null) {
        return m;
      }
    }
    return search(c.getSuperclass(), name, params, seen);
  }
}
