#!/usr/bin/env python3
"""
Merge progress made under the OFFLINE uuid back into the REAL (premium) uuid.
STOP the Paper servers first. Default is DRY-RUN; add --apply to change files.

players.txt  (one per line):   Name,premium-uuid
Example:      ExoticCrown,c5763ac3-ee2c-40dd-86cc-250363b1b010

Usage:
  python3 migrate_uuids.py players.txt /srv/hub /srv/boxpvp /srv/ffacrystal
  python3 migrate_uuids.py players.txt /srv/hub --apply

Per player file the offline copy replaces the premium copy ONLY if it is newer.
The old premium file is kept as <file>.premiumbak. Does NOT touch databases
(LuckPerms/Essentials on MySQL, etc).
"""
import argparse, glob, hashlib, os, shutil, sys, uuid

def offline_uuid(name):
    h = bytearray(hashlib.md5(("OfflinePlayer:" + name).encode()).digest())
    h[6] = (h[6] & 0x0F) | 0x30
    h[8] = (h[8] & 0x3F) | 0x80
    return str(uuid.UUID(bytes=bytes(h)))

PATTERNS = [
    "*/playerdata/{u}.dat",
    "*/stats/{u}.json",
    "*/advancements/{u}.json",
    "plugins/Essentials/userdata/{u}.yml",
]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("players")
    ap.add_argument("servers", nargs="+")
    ap.add_argument("--apply", action="store_true")
    a = ap.parse_args()

    players = []
    for line in open(a.players, encoding="utf-8"):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        name, prem = [x.strip() for x in line.split(",")]
        players.append((name, str(uuid.UUID(prem))))

    for srv in a.servers:
        print(f"== {srv}")
        for name, prem in players:
            off = offline_uuid(name)
            for pat in PATTERNS:
                for off_file in glob.glob(os.path.join(srv, pat.format(u=off))):
                    prem_file = off_file.replace(off, prem)
                    if not os.path.exists(prem_file):
                        action = "COPY (no premium file yet)"
                    elif os.path.getmtime(off_file) > os.path.getmtime(prem_file):
                        action = "REPLACE (offline is newer)"
                    else:
                        print(f"  skip   {name}: {os.path.relpath(off_file, srv)} (premium is newer)")
                        continue
                    print(f"  {'DO' if a.apply else 'would'} {action}: {name}: {os.path.relpath(off_file, srv)}")
                    if a.apply:
                        if os.path.exists(prem_file):
                            shutil.copy2(prem_file, prem_file + ".premiumbak")
                        shutil.copy2(off_file, prem_file)
    if not a.apply:
        print("\nDry-run only. Add --apply to write changes.")

if __name__ == "__main__":
    sys.exit(main())
